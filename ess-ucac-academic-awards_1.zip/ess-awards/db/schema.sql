-- ESS-UCAC ACADEMIC AWARDS - Schema Supabase (PostgreSQL)
-- A executer dans Supabase > SQL Editor

create table if not exists categories (
  id serial primary key,
  slug text unique not null,
  nom text not null,
  ordre integer not null,
  icone text
);

insert into categories (slug, nom, ordre, icone) values
  ('meilleur-delegue', 'Meilleur(e) Délégué(e)', 1, 'podium'),
  ('meilleur-entrepreneur', 'Meilleur(e) Entrepreneur(e)', 2, 'briefcase'),
  ('excellence-academique', 'Excellence Académique', 3, 'graduation-cap'),
  ('meilleur-club', 'Meilleur Club', 4, 'users'),
  ('meilleure-classe', 'Meilleure Classe', 5, 'users-group'),
  ('meilleur-leader', 'Meilleur(e) Leader', 6, 'podium'),
  ('prix-special-jury', 'Prix Spécial du Jury', 7, 'trophy')
on conflict (slug) do nothing;

create table if not exists nominees (
  id uuid primary key default gen_random_uuid(),
  category_id integer references categories(id) on delete cascade,
  nom_complet text not null,
  classe_ou_filiere text,
  bio text,
  photo_url text,
  statut text default 'valide' check (statut in ('en_attente','valide','refuse')),
  date_creation timestamptz default now()
);

create table if not exists votes (
  id uuid primary key default gen_random_uuid(),
  nominee_id uuid references nominees(id) on delete cascade,
  methode text not null check (methode in ('mobile_money')),
  operateur text check (operateur in ('orange_money','mtn_momo')),
  telephone_votant text,
  reference_transaction text,
  montant integer not null default 100,
  statut_paiement text default 'en_attente' check (statut_paiement in ('en_attente','confirme','rejete')),
  date_vote timestamptz default now()
);

create table if not exists settings (
  cle text primary key,
  valeur text
);

insert into settings (cle, valeur) values
  ('vote_ouverture', '2026-07-03T00:00:00Z'),
  ('vote_fermeture', '2026-07-10T18:00:00Z'),
  ('prix_vote', '100'),
  ('numero_orange_money', 'A_DEFINIR'),
  ('numero_mtn_momo', 'A_DEFINIR')
on conflict (cle) do nothing;

-- Index utiles
create index if not exists idx_nominees_category on nominees(category_id);
create index if not exists idx_votes_nominee on votes(nominee_id);
create index if not exists idx_votes_statut on votes(statut_paiement);

-- Vue: classement en temps reel (votes confirmes uniquement)
create or replace view classement as
select
  n.id as nominee_id,
  n.nom_complet,
  n.photo_url,
  c.id as category_id,
  c.nom as categorie,
  count(v.id) as total_votes
from nominees n
join categories c on c.id = n.category_id
left join votes v on v.nominee_id = n.id and v.statut_paiement = 'confirme'
group by n.id, n.nom_complet, n.photo_url, c.id, c.nom
order by c.ordre, total_votes desc;
